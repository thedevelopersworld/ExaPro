from django.db import models

class Register(models.Model):
        name = models.CharField(max_length=30)
        email = models.EmailField(max_length=50,primary_key=True)
        password = models.CharField(max_length=15)


        