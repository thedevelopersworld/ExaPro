from django.urls import path
from authentication import views

urlpatterns = [

    path('signup', views.signup),
    path('login', views.login),
    path('logout', views.logout,name="logout"),
    path('verify',views.verify),
    path('generate',views.generate,name="generate"),
    path('change_pass',views.change_pass),
    path('verify_change_pass',views.verify_change_pass),
    path('show',views.show),
    
]
    