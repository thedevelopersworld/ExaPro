from django.apps import AppConfig


class SiteConfig(AppConfig):
    name = 'site_'
    label = 'my_site_'